# HOKADIW Terminal Distribution v0.1 (ARM64 MVP)

This is the build/orchestration layer for an independent Android terminal distribution derived from Termux upstream source.

## Identity

- App name: `HOKADIW Terminal`
- Android application id: `com.hokadiw.terminal`
- Data dir: `/data/data/com.hokadiw.terminal`
- Rootfs: `/data/data/com.hokadiw.terminal/files`
- HOME: `/data/data/com.hokadiw.terminal/files/home`
- PREFIX: `/data/data/com.hokadiw.terminal/files/usr`
- First target: Android 7+ / `aarch64` (`arm64-v8a`)

The Java source namespace stays `com.termux` in v0.1. Android `applicationId`, runtime package constants,
bootstrap target and manifest placeholders are changed. This gives HOKADIW a separate Android identity
and separate runtime filesystem without doing a risky full Java namespace rename.

## Build flow

The GitHub Actions workflow:

1. Clones `termux/termux-packages`.
2. Patches the package build identity to `com.hokadiw.terminal`.
3. Patches APT's initial source to the HOKADIW repository.
4. Adds the custom `hokadiw-tools` package and builds the `aarch64` bootstrap from source.
5. Collects the `.deb` files produced by that build.
6. Generates a flat HOKADIW APT repository.
7. Clones `termux/termux-app`.
8. Patches Android identity/runtime constants.
9. Embeds the custom `bootstrap-aarch64.zip`.
10. Builds an ARM64-only debug APK.
11. Uploads APK + bootstrap + APT repository as an Actions artifact.

## Development APT URL

`https://p-dev3.github.io/hokadiw-toolkit/apt`

v0.1 uses `[trusted=yes]` only to prove the full independent build loop.
Before a public release, replace this with a persistent HOKADIW GPG signing key,
signed `Release/InRelease`, and a HOKADIW keyring installed in the bootstrap.

## Run on GitHub

Push this overlay into:

`https://github.com/p-dev3/hokadiw-toolkit`

A push to `main` starts **Build HOKADIW Distribution** automatically. You can also run it manually from Actions.

Download artifact:

`hokadiw-distribution-arm64`

## Publish the development package repository

After a runtime build, copy `dist/runtime/apt-repo/` into `docs/apt/`:

```sh
bash scripts/publish-dev-repo.sh
git add docs/apt
git commit -m "Publish HOKADIW development APT repo"
git push
```

Then enable GitHub Pages for `main` branch `/docs`.

## Local/VPS build

Linux + Docker:

```sh
bash scripts/build-runtime.sh
bash scripts/build-app.sh
```

## v0.1 success criteria

```text
APK package:  com.hokadiw.terminal
PREFIX:       /data/data/com.hokadiw.terminal/files/usr
Bootstrap:    custom bootstrap-aarch64.zip
APT source:   HOKADIW repository
Packages:     rebuilt for the HOKADIW PREFIX
Command:      hkd (from hokadiw-tools)
```

That is the first complete HOKADIW runtime/package ecosystem loop.
