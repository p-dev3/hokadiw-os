#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

REPO="https://github.com/p-dev3/hokadiw-toolkit.git"

pkg install -y git tar

git init 2>/dev/null || true
git branch -M main

if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO"
else
  git remote add origin "$REPO"
fi

git add .
if ! git diff --cached --quiet; then
  git commit -m "Add HOKADIW independent runtime and package ecosystem v0.1"
fi
git push -u origin main
