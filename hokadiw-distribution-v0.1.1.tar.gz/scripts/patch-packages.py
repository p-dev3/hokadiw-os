#!/usr/bin/env python3
from pathlib import Path
import argparse

def replace_required(path: Path, old: str, new: str):
    text = path.read_text(encoding="utf-8")
    if old not in text:
        raise SystemExit(f"Expected text not found in {path}: {old!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--package", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--owner", required=True)
    ap.add_argument("--apt-url", required=True)
    args = ap.parse_args()

    root = Path(args.root).resolve()
    props = root / "scripts/properties.sh"
    apt = root / "packages/apt/build.sh"

    if not props.exists() or not apt.exists():
        raise SystemExit(f"{root} is not a termux-packages checkout")

    replace_required(props, 'TERMUX__NAME="Termux"', f'TERMUX__NAME="{args.name}"')
    replace_required(
        props,
        'TERMUX__REPOS_HOST_ORG_NAME="termux"',
        f'TERMUX__REPOS_HOST_ORG_NAME="{args.owner}"'
    )
    replace_required(
        props,
        'TERMUX_APP__PACKAGE_NAME="com.termux"',
        f'TERMUX_APP__PACKAGE_NAME="{args.package}"'
    )

    text = apt.read_text(encoding="utf-8")
    old = (
        '\t{\n'
        '\t\techo "# The main termux repository, with cloudflare cache"\n'
        '\t\techo "deb https://packages-cf.termux.dev/apt/termux-main/ stable main"\n'
        '\t\techo "# The main termux repository, without cloudflare cache"\n'
        '\t\techo "# deb https://packages.termux.dev/apt/termux-main/ stable main"\n'
        '\t} > $TERMUX_PREFIX/etc/apt/sources.list'
    )
    new = (
        '\t{\n'
        '\t\techo "# HOKADIW development repository"\n'
        f'\t\techo "deb [trusted=yes] {args.apt_url} ./"\n'
        '\t} > $TERMUX_PREFIX/etc/apt/sources.list'
    )
    if old not in text:
        raise SystemExit("Could not locate upstream APT sources.list generation block")
    apt.write_text(text.replace(old, new), encoding="utf-8")

    pkgdir = root / "packages/hokadiw-tools"
    pkgdir.mkdir(parents=True, exist_ok=True)
    (pkgdir / "build.sh").write_text(
        """TERMUX_PKG_HOMEPAGE=https://github.com/p-dev3/hokadiw-toolkit
TERMUX_PKG_DESCRIPTION=\"Core dashboard and utilities for HOKADIW Terminal\"
TERMUX_PKG_LICENSE=MIT
TERMUX_PKG_MAINTAINER=\"HOKADIW\"
TERMUX_PKG_VERSION=0.1.0
TERMUX_PKG_SKIP_SRC_EXTRACT=true
TERMUX_PKG_PLATFORM_INDEPENDENT=true
TERMUX_PKG_DEPENDS=\"bash, coreutils, termux-tools\"

termux_step_make_install() {
    sed "s|@TERMUX_PREFIX@|$TERMUX_PREFIX|g" $TERMUX_PKG_BUILDER_DIR/hkd > $TERMUX_PREFIX/bin/hkd
    chmod 700 $TERMUX_PREFIX/bin/hkd
}
""",
        encoding="utf-8",
    )
    (pkgdir / "hkd").write_text(
        """#!@TERMUX_PREFIX@/bin/bash
set -u
while true; do
  clear
  printf '\033[1;95mHOKADIW TERMINAL\033[0m\n'
  printf 'Runtime: %s\n' \"${PREFIX:-unknown}\"
  printf '\n1. System info\n2. Update packages\n3. List installed packages\n4. Show APT sources\n0. Exit\n> '
  read -r choice
  case \"$choice\" in
    1) uname -a; echo; getprop ro.product.model 2>/dev/null || true; read -r _ ;;
    2) apt update; read -r _ ;;
    3) dpkg -l | less ;;
    4) cat \"$PREFIX/etc/apt/sources.list\" 2>/dev/null || true; read -r _ ;;
    0) exit 0 ;;
  esac
done
""",
        encoding="utf-8",
    )

    (root / "HOKADIW_BUILD_IDENTITY.txt").write_text(
        f"NAME={args.name}\nPACKAGE={args.package}\nAPT_URL={args.apt_url}\n",
        encoding="utf-8",
    )

    print("Patched termux-packages for HOKADIW")
    print(f"package={args.package}")
    print(f"apt={args.apt_url}")
    print("TERMUX__INTERNAL_NAME kept as termux for v0.1")

if __name__ == "__main__":
    main()
