#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/config.env"

WORK="${HOKADIW_WORK:-$ROOT/.work}"
APP_DIR="$WORK/termux-app"
RUNTIME="$ROOT/dist/runtime"
OUT="$ROOT/dist/app"

BOOTSTRAP="$RUNTIME/bootstrap-${HOKADIW_ARCH}.zip"
if [ ! -f "$BOOTSTRAP" ]; then
  echo "Missing $BOOTSTRAP; run build-runtime.sh first" >&2
  exit 1
fi

rm -rf "$APP_DIR" "$OUT"
mkdir -p "$WORK" "$OUT"

git clone https://github.com/termux/termux-app.git "$APP_DIR"
git -C "$APP_DIR" checkout "$TERMUX_APP_REF"

python3 "$ROOT/scripts/patch-app.py" "$APP_DIR" \
  --package "$HOKADIW_PACKAGE" \
  --app-name "$HOKADIW_APP_NAME"

mkdir -p "$APP_DIR/app/src/main/cpp"
cp "$BOOTSTRAP" "$APP_DIR/app/src/main/cpp/bootstrap-aarch64.zip"

(
  cd "$APP_DIR"
  export TERMUX_PACKAGE_VARIANT="apt-android-7"
  export TERMUX_SPLIT_APKS_FOR_DEBUG_BUILDS="0"
  export TERMUX_APP_VERSION_NAME="0.1.0"
  export TERMUX_APK_VERSION_TAG="hokadiw-v0.1-arm64-debug"
  ./gradlew --no-daemon assembleDebug
)

APK="$(find "$APP_DIR/app/build/outputs/apk/debug" -type f -name '*.apk' | head -n 1)"
if [ -z "$APK" ]; then
  echo "APK not found" >&2
  exit 1
fi

cp "$APK" "$OUT/HOKADIW-Terminal-v0.1-arm64-debug.apk"
(
  cd "$OUT"
  sha256sum *.apk > SHA256SUMS
)
echo "APK build complete:"
ls -lh "$OUT"
