#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT/dist/runtime/apt-repo"
DST="$ROOT/docs/apt"

[ -d "$SRC" ] || {
  echo "Missing $SRC; build runtime first" >&2
  exit 1
}

rm -rf "$DST"
mkdir -p "$DST"
cp -a "$SRC"/. "$DST"/

echo "Copied development APT repository to docs/apt"
