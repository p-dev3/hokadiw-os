#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"

python3 -m py_compile \
  "$ROOT/scripts/patch-packages.py" \
  "$ROOT/scripts/patch-app.py"

for f in \
  "$ROOT/scripts/build-runtime.sh" \
  "$ROOT/scripts/build-app.sh" \
  "$ROOT/scripts/make-flat-repo.sh" \
  "$ROOT/scripts/publish-dev-repo.sh"
do
  bash -n "$f"
done

echo "Static checks passed."
