#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "usage: $0 DEB_DIR OUTPUT_REPO_DIR" >&2
  exit 2
fi

DEB_DIR="$(realpath "$1")"
OUT="$(realpath -m "$2")"

command -v dpkg-scanpackages >/dev/null 2>&1 || {
  echo "dpkg-scanpackages missing; install dpkg-dev" >&2
  exit 1
}

rm -rf "$OUT"
mkdir -p "$OUT"
cp -f "$DEB_DIR"/*.deb "$OUT/"

(
  cd "$OUT"
  dpkg-scanpackages . /dev/null > Packages
  gzip -9c Packages > Packages.gz
  sha256sum Packages Packages.gz *.deb > SHA256SUMS
)

echo "APT repository created: $OUT"
