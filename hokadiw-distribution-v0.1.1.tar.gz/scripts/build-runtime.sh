#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/config.env"

WORK="${HOKADIW_WORK:-$ROOT/.work}"
PACKAGES_DIR="$WORK/termux-packages"
OUT="$ROOT/dist/runtime"

mkdir -p "$WORK"
rm -rf "$PACKAGES_DIR" "$OUT"

git clone https://github.com/termux/termux-packages.git "$PACKAGES_DIR"
git -C "$PACKAGES_DIR" checkout "$TERMUX_PACKAGES_REF"

python3 "$ROOT/scripts/patch-packages.py" "$PACKAGES_DIR" \
  --package "$HOKADIW_PACKAGE" \
  --name "$HOKADIW_NAME" \
  --owner "$HOKADIW_GITHUB_OWNER" \
  --apt-url "$HOKADIW_APT_URL"

(
  cd "$PACKAGES_DIR"
  ./scripts/run-docker.sh ./clean.sh || true
  ./scripts/run-docker.sh ./scripts/build-bootstraps.sh \
    --architectures "$HOKADIW_ARCH" \
    --add hokadiw-tools \
    -f
)

mkdir -p "$OUT/debs"
cp "$PACKAGES_DIR/bootstrap-${HOKADIW_ARCH}.zip" "$OUT/"
find "$PACKAGES_DIR/output" -maxdepth 1 -type f -name '*.deb' \
  -exec cp -f {} "$OUT/debs/" \;

bash "$ROOT/scripts/make-flat-repo.sh" "$OUT/debs" "$OUT/apt-repo"

echo "Runtime build complete:"
find "$OUT" -maxdepth 2 -type f -print | sort
