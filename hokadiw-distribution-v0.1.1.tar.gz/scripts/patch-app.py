#!/usr/bin/env python3
from pathlib import Path
import argparse, re

def replace_required(path: Path, old: str, new: str):
    text = path.read_text(encoding="utf-8")
    if old not in text:
        raise SystemExit(f"Expected text not found in {path}: {old!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")

def patch_java_string_literals(path: Path, old_prefix: str, new_prefix: str):
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r'"' + re.escape(old_prefix) + r'([^"]*)"')
    text2, count = pattern.subn(lambda m: '"' + new_prefix + m.group(1) + '"', text)
    if count == 0:
        raise SystemExit(f"No {old_prefix!r} string literals found in {path}")
    path.write_text(text2, encoding="utf-8")
    return count

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--package", required=True)
    ap.add_argument("--app-name", required=True)
    args = ap.parse_args()

    root = Path(args.root).resolve()
    gradle = root / "app/build.gradle"
    app_strings = root / "app/src/main/res/values/strings.xml"
    shared_strings = root / "termux-shared/src/main/res/values/strings.xml"
    constants = root / "termux-shared/src/main/java/com/termux/shared/termux/TermuxConstants.java"

    for p in [gradle, app_strings, shared_strings, constants]:
        if not p.exists():
            raise SystemExit(f"Missing expected upstream file: {p}")

    text = gradle.read_text(encoding="utf-8")

    target = "    defaultConfig {\n        minSdkVersion"
    replacement = (
        "    defaultConfig {\n"
        f'        applicationId "{args.package}"\n'
        "        minSdkVersion"
    )
    if target not in text:
        raise SystemExit("Could not locate defaultConfig")
    text = text.replace(target, replacement, 1)

    replace_pairs = {
        'manifestPlaceholders.TERMUX_PACKAGE_NAME = "com.termux"':
            f'manifestPlaceholders.TERMUX_PACKAGE_NAME = "{args.package}"',
        'manifestPlaceholders.TERMUX_APP_NAME = "Termux"':
            f'manifestPlaceholders.TERMUX_APP_NAME = "{args.app_name}"',
    }
    for old, new in replace_pairs.items():
        if old not in text:
            raise SystemExit(f"Could not locate {old}")
        text = text.replace(old, new)

    sdk_line = "        targetSdkVersion project.properties.targetSdkVersion.toInteger()\n"
    if sdk_line not in text:
        raise SystemExit("Could not locate targetSdkVersion")
    text = text.replace(
        sdk_line,
        sdk_line + "        ndk { abiFilters 'arm64-v8a' }\n",
        1
    )

    start = text.find("task downloadBootstraps() {")
    end = text.find("\nafterEvaluate {", start)
    if start < 0 or end < 0:
        raise SystemExit("Could not locate downloadBootstraps task")

    local_task = '''task downloadBootstraps() {
    doLast {
        def file = new File(projectDir, "src/main/cpp/bootstrap-aarch64.zip")
        if (!file.exists()) {
            throw new GradleException("Missing HOKADIW bootstrap: " + file)
        }
        logger.quiet("Using local HOKADIW bootstrap " + file)
    }
}
'''
    text = text[:start] + local_task + text[end:]
    gradle.write_text(text, encoding="utf-8")

    replace_required(
        app_strings,
        '<!ENTITY TERMUX_APP_NAME "Termux">',
        f'<!ENTITY TERMUX_APP_NAME "{args.app_name}">'
    )
    replace_required(
        app_strings,
        '<!ENTITY TERMUX_PACKAGE_NAME "com.termux">',
        f'<!ENTITY TERMUX_PACKAGE_NAME "{args.package}">'
    )

    shared = shared_strings.read_text(encoding="utf-8")
    shared = shared.replace("com.termux", args.package)
    shared_strings.write_text(shared, encoding="utf-8")

    count = patch_java_string_literals(constants, "com.termux", args.package)

    (root / "HOKADIW_APP_IDENTITY.txt").write_text(
        f"APP_NAME={args.app_name}\n"
        f"APPLICATION_ID={args.package}\n"
        f"PATCHED_CONSTANT_STRINGS={count}\n",
        encoding="utf-8"
    )

    print("Patched termux-app")
    print(f"applicationId={args.package}")
    print("ABI=arm64-v8a")
    print("bootstrap=local bootstrap-aarch64.zip")

if __name__ == "__main__":
    main()
