# Upstream / security notes

HOKADIW Terminal v0.1 is derived from Termux upstream projects.

Upstream Termux explicitly requires forks that change package name to update app constants
and rebuild bootstrap archives for the new package name.

v0.1 intentionally keeps the internal source namespace/name `termux` where practical while
changing Android application identity, runtime filesystem location, build-time package identity,
bootstrap and APT source.

## Development repository trust

The v0.1 APT source uses `trusted=yes`. This disables repository-signature verification.
It is only for proving the end-to-end MVP.

Before public release:
- create a persistent offline-protected HOKADIW APT signing key,
- publish its public key/keyring,
- sign Release/InRelease metadata,
- remove `trusted=yes`.

## APK signing

Do not use a shared upstream test key for public HOKADIW releases.
Create and securely retain a HOKADIW release keystore.
